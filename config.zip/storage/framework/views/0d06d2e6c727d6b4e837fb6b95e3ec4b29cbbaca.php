<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html;" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="0y3-Trovolink" content="">

        <title> <?php echo $__env->yieldContent('title'); ?> </title>

        <!-- Favicon -->
        

        <!-- Styles -->
        <link href="<?php echo e(asset('assets/css/font-awesome-all.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/flaticon.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/owl.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/jquery.fancybox.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/color.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/swiper-min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/theme-template.css')); ?>" rel="stylesheet">

        <!-- for page specific stylesheet -->
        <?php echo $__env->yieldPushContent('styles'); ?>

    </head>

    <!-- page wrapper -->
    <body>

        <div class="boxed_wrapper">

            <!-- main-header -->
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <!-- main-header end -->

            <!-- main-content -->
            <?php echo $__env->yieldContent('content'); ?> 
            <!-- main-content end -->

            <!-- main-footer -->
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- main-footer end -->
            
            <!-- scroll to top -->
            <button class="scroll-top style-two scroll-to-target" data-target="html">
                <i class="fas fa-angle-up"></i>
            </button>

        </div>


        <!-- jquery plugins -->
        <script src="<?php echo e(asset("assets/js/jquery.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/popper.min.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/bootstrap.min.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/owl.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/wow.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/validation.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/jquery.fancybox.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/appear.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/scrollbar.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/tilt.jquery.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/isotope.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/bxslider.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/swiper-min.js")); ?>"></script>
        <script src="<?php echo e(asset("assets/js/jquery-magnific-popup.js")); ?>"></script>
        

        <!-- main-js -->
        <script src="<?php echo e(asset("assets/js/script.js")); ?>"></script>

        <!--for page specific script-->
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body><!-- End of .page_wrapper -->

</html>
<?php /**PATH C:\Users\USER\Documents\0Y3 js\fibrehub\resources\views/layouts/mainlayout.blade.php ENDPATH**/ ?>