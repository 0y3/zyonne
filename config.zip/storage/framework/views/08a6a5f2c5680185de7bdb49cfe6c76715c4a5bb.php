<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    

    <!-- banner-section -->
    <section class="position-relative bg-white overflow-hidden py-lg-11">
        <div class="container">

            <div class="row align-items-center justify-content-between">
                <div class="col-lg-5 mb-7 mb-lg-0">
                    <div class="position-relative d-table mb-5">
                        <h5 class="text-warning ban-font-weight"><i class="far fa-wifi"></i> Turbo-Speed Internet up to <b>200Mbps</b></h5>
                        <h2 class="display-1 me-lg-n15 mb-4 position-relative">Best Internet Service<br>In Your <b class="text-primary">Region.</b></h2>
                        </h2>

                        <!--text-->
                        <p class="lead mb-0 me-lg-n14">
                            Fast Speed + No Service Charge + Contracts + Cloud Connectivity
                        </p>
                    </div>
                    
                    <div class="action-btns mts-5">
                        <a href="" class="btn style1">View Services</a>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <div class="position-relative">
                        <img src="<?php echo e(asset('assets/picture/banner-img1.png')); ?>" class="img-fluid d-block w-100 h-auto position-relative" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- banner-section end -->


    <!-- service-style-four -->
    <section class="service-style-four" style="background-image: url(<?php echo e(asset('assets/image/shape-52.png')); ?>);">
        <div class="auto-container">
            <div class="sec-title2 d-flex align-items-center mb-60 md-mb-40">
                <div class="first-half">
                    <div class="sub-text">What We Offer</div>
                    <h2 class="title mb-0 md-pb-20">Services we provide to our customers & <span>businesses.</span>
                    </h2>
                </div>
            </div>
        </div>



        <div class="outer-container">
            
            <div class="content_block_11">
                <div class="content-box-1">
                    <div class="four-item-carousel owl-carousel owl-theme owl-nav-none dots-style-one">
                            
                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/signal_tower.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Radio Communication</h3>
                                    <p>We leverages advanced radio communication technology to provide
                                    reliable and high-speed internet connectivity to customers in remote or challenging locations</p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/smart_house.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Fiber to Home (FTTH)</h3>
                                    <p>
                                        We brings the future of broadband directly to customers homes. With FTTH, 
                                        customers can experience lightning-fast internet speeds, seamless streaming & smooth online gaming.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/smart_office.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Fiber to Office (FTTO)</h3>
                                    <p>
                                        FTTO solutions enable businesses to take advantage of ultra-fast and reliable internet connections.
                                        By deploying fiber optic cables directly to offices
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/5145806.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Dedicated Internet Access <br>(DIA)</h3>
                                    <p>
                                        We offers dedicated internet connections for businesses, providing exclusive 
                                        bandwidth and symmetrical speeds. With DIA, 
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/icon-6.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Virtual Private Network (VPN)</h3>
                                    <p>
                                        We enables businesses to establish secure and private 
                                        connections through its VPN services. By encrypting data transmissions, 
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/cloud.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Cloud Connectivity</h3>
                                    <p>
                                        We facilitates seamless integration with leading cloud service providers, 
                                        enabling businesses to securely store and access their data, applications, and resources. 
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="service-block-four single-columnn">
                            <div class="inner-box">
                                <div class="single-item">
                                    <figure class="icon-box"><img src="<?php echo e(asset('assets/picture/7109537.png')); ?>" alt="" height="64" width="64"></figure>
                                    <h3>Voice over Internet Protocol (VoIP)</h3>
                                    <p>
                                        We provides cost-effective VoIP solutions, 
                                        enabling businesses to leverage internet-based phone systems
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>


            </div>
        </div>
       <div class="more-btn centred mr-25">
                <a href="service.html" class="theme-btn btn-ten">All Services</a>
            </div>
    </section>
    <!-- service-style-four end -->


    <!-- Start About Five -->
    <section class="about_five-wrap pt-100 pb-100">
        <div class="container">
            <div class="row gx-5 align-items-center">
                <div class="col-lg-6">
                    <div class="about_five-content">
                        <div class="sec-title2 mb-30">
                            <div class="sub-text">ABOUT US</div>
                            <h2 class="title mb-23">We specializes in providing<br> High-Speed Internet <span>Broadband Services.</span></h2>
                        </div>
                        
                        <p>
                            FibreHub is a leading telecommunications company that specializes in providing high-speed internet broadband services. 
                            With a commitment to delivering reliable and efficient connectivity solutions, FibreHub utilizes cutting-edge technologies, 
                            including radio communication and fiber optic networks, to ensure seamless connectivity for both residential and commercial customers. 
                            Alongside its robust broadband services, FibreHub offers a wide range of enterprise services, catering to the diverse needs of businesses across various industries.
                        </p>
                        <div class="row align-items-start gx-5">
                            <div class="col-md-8">
                                <div class="contact-item-wrap">
                                    <div class="contact-item">
                                        <span><i class="fa fa-phone"></i></span>
                                        <a href="tel:+2348090506310">+23480 9050 6310</a>
                                    </div>
                                    <div class="contact-item">
                                        <div class="contact-item">
                                            <span> <i class="fa fa-clock"></i></span>
                                            <p>Everyday 24/7</p>
                                        </div>
                                    </div>
                                    <div class="contact-item">
                                        <div class="contact-item">
                                            <span> <i class="fa fa-envelope"></i></span>
                                            <p>info@fibrehub.com.ng</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="image-box">
                        <figure class="image"><img src="<?php echo e(asset('assets/picture/about-img1.png')); ?>" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End About Five -->

     <!--Start Section content -->
     <section class="about-style-seven ptb-100 content-bg-img-siz" style="background-image: url(<?php echo e(asset('assets/image/shape-68.png')); ?>); background-color: black;">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-sm-12 content-column">
                    <div class="content_block_15">
                        <div class="content-box">
                            <div class="sec-title style-two">
                                <h2>Areas we've covered</h2>
                            </div>
                            <div class="text">
                                
                                <ul class="list clearfix list-flex">
                                    <li>Adekoya Est. (Ikeja)</li>
                                    <li>Omole Est. Phase 1 (Ikeja)</li>
                                    <li>Omole Est. Phase 2 (Olowora)</li>
                                    <li>Sparklight Est. (Opic)</li>
                                    <li>Adeoni Est. (Ojodu)</li>
                                    <li>Morgan Est. Phase 1&2 (Ojodu)</li>
                                    <li>Karaole Est. (Ogba)</li>
                                    <li>Vanni Est. (Ojodu)</li>
                                    <li>Goodwill Est. (Ojodu)</li>
                                    <li>Unity Est. (Ojodu)</li>
                                    <li>Harmony Est. (Agege)</li>
                                    <li>Gorgeous Cole Est. (Agege)</li>
                                    <li>Victory Est.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Section content -->


    <!-- service-style-six -->
    <section class="service-style-six">
        <div class="sec-title2 mb-30 sb-1">
            <div class="sub-text">WHY CHOOSE US</div>
            <h2 class="title mb-23">Why People Use<br> FibreHub <span><b>Fibre Internet.</b></span></h2>
        </div>
        <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 service-block">
                        <div class="service-block-six">
                            <div class="inner-box">
                                <div class="shape" style="background-image: url(<?php echo e(asset('assets/image/shape-51.png')); ?>);"></div>
                                <div class="icon-box">
                                    <div class="icon"><i class="flaticon-science"></i></div>
                                    <div class="icon-shape" style="background-image: url(<?php echo e(asset('assets/image/bg-shape-1.png')); ?>);"></div>
                                </div>
                                <h3>Fastest Broadband speeds</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 service-block">
                        <div class="service-block-six">
                            <div class="inner-box">
                                <div class="shape" style="background-image: url(<?php echo e(asset('assets/image/shape-51.png')); ?>);"></div>
                                <div class="icon-box">
                                    <div class="icon"><i class="flaticon-virtual-reality"></i></div>
                                    <div class="icon-shape" style="background-image: url(<?php echo e(asset('assets/image/bg-shape-1.png')); ?>);"></div>
                                </div>
                                <h3><b>24/7</b> call service</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 service-block">
                        <div class="service-block-six">
                            <div class="inner-box">
                                <div class="shape" style="background-image: url(<?php echo e(asset('assets/image/shape-51.png')); ?>);"></div>
                                <div class="icon-box">
                                    <div class="icon"><i class="flaticon-artificial-intelligence"></i></div>
                                    <div class="icon-shape" style="background-image: url(<?php echo e(asset('assets/image/bg-shape-1.png')); ?>);"></div>
                                </div>
                                <h3>Fiber optic connection</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 service-block">
                        <div class="service-block-six">
                            <div class="inner-box">
                                <div class="shape" style="background-image: url(<?php echo e(asset('assets/image/shape-51.png')); ?>);"></div>
                                <div class="icon-box">
                                    <div class="icon"><i class="flaticon-data-science"></i></div>
                                    <div class="icon-shape" style="background-image: url(<?php echo e(asset('assets/image/bg-shape-1.png')); ?>);"></div>
                                </div>
                                <h3>IPv6 supported dedicated</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 service-block">
                        <div class="service-block-six">
                            <div class="inner-box">
                                <div class="shape" style="background-image: url(<?php echo e(asset('assets/image/')); ?>);"></div>
                                <div class="icon-box">
                                    
                                    <div class="icon-shape" style="background-image: url(<?php echo e(asset('assets/image/led.png')); ?>); background-size: cover;"></div>
                                </div>
                                <h3>4K & 8K Streaming Speed</h3>
                                <p>Get connected with FibreHub that can provide your every technology need to connect the world.</p>
                            </div>
                        </div>
                    </div>
                </div>
           
        </div>
    </section>
    <!-- service-style-six end -->

    <!-- Start Pricing Five Section-->
    
    <!-- End Pricing Five Section -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\0Y3 js\fibrehub\resources\views/index.blade.php ENDPATH**/ ?>