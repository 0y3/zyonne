<footer class="main-footer footer-style-six footer-digital">
    
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="bottom-inner clearfix">
                <div class="copyright pull-left">
                    <p>Copyright © <?php echo e(date('Y')); ?> Powered by <a target="_blank" href="">Trovolink</a>.Company name All rights reserved.</p>
                </div>
                
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\USER\Documents\0Y3 js\fibrehub\resources\views/layouts/footer.blade.php ENDPATH**/ ?>