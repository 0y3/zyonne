<!-- main header -->
<header class="main-header header-style-two">
    <!-- header-top-two -->
    <div class="header-top-two">
        <div class="auto-container-fluid">
            <div class="top-inner clearfix">
                <div class="bg-layer"></div>
                <div class="support-box pull-left">
                    <p><i class="fas fa-phone"></i>Let's talk with our experts<a href="tel:+2348090506310">+23480 9050 6310</a></p>
                </div>
                <ul class="social-links pull-right clearfix">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-dribbble"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- header-lower -->
    <div class="header-lower">
        <div class="auto-container-fluid">
            <div class="outer-box clearfix bg-white">
                <div class="logo-box pull-left">
                    <figure class="logo"><a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('assets/picture/fibrehublogo_purple.png')); ?>" width="150px" alt=""></a></figure>
                </div>
                <div class="menu-area pull-right clearfix">
                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler">
                        <i class="icon-bar"></i>
                        <i class="icon-bar"></i>
                        <i class="icon-bar"></i>
                    </div>
                    <nav class="main-menu navbar-expand-md navbar-light">
                        <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                            <ul class="navigation clearfix">
                                <li class=""><a href="<?php echo e(route('index')); ?>">Home</a></li>
                                <li class=""><a href="<?php echo e(route('index')); ?>">Services</a></li>
                                <li class=""><a href="<?php echo e(route('plan')); ?>">Plans</a></li>
                                <li class=""><a href="<?php echo e(route('index')); ?>">Contact us</a></li>
                                <li class=""><a href="https://fibrehub.phpradius.com/" target="_blank">Self-Service</a></li>
                            </ul>
                        </div>
                    </nav>
                    
                </div>
            </div>
        </div>
    </div>

    <!--sticky Header-->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="outer-box clearfix">
                <figure class="sticky-logo pull-left">
                    <a href="<?php echo e(route("index")); ?>"><img src="<?php echo e(asset('assets/picture/fibrehublogo_white.png')); ?>" width="150px" alt=""></a>
                </figure>
                <div class="menu-area pull-right clearfix">
                    <nav class="main-menu clearfix">
                        <!--Keep This Empty / Menu will come through Javascript-->
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- main-header end -->

<!-- Mobile Menu  -->
<div class="mobile-menu">
    <div class="menu-backdrop"></div>
    <div class="close-btn"><i class="fas fa-times"></i></div>
    
    <nav class="menu-box">
        <div class="nav-logo"><a href="<?php echo e(route("index")); ?>"><img src="<?php echo e(asset('assets/picture/fibrehublogo_white.png')); ?>" width="150px"  alt="" title=""></a></div>
        <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
        <div class="contact-info">
            <h4>Contact Info</h4>
            <ul>
                <li>124, queens walk 2nd cross denmark WA, Australia</li>
                <li><a href="tel:+12012467481">+12012467481</a></li>
                <li><a href="mailto:support@demo.com">support@demo.com</a></li>
            </ul>
        </div>
        <div class="social-links">
            <ul class="clearfix">
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                <li><a href="#"><span class="fab fa-youtube"></span></a></li>
            </ul>
        </div>
    </nav>
</div><!-- End Mobile Menu --><?php /**PATH C:\Users\USER\Documents\0Y3 js\fibrehub\resources\views/layouts/header.blade.php ENDPATH**/ ?>